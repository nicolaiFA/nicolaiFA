# Example Master's thesis

This is an example of a scientific project/master's thesis. It is the formatting I used for my own Master's thesis.
